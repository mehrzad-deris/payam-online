const initServerProductFilters = () => {
    document.querySelectorAll('[data-server-product-browser]').forEach((browser) => {
        if (browser.dataset.serverFiltersReady === 'true') return;

        const form = browser.querySelector('[data-server-filters]');
        const selects = Array.from(
            form?.querySelectorAll('[data-server-filter-select]') || []
        );

        if (!form || !selects.length) return;

        browser.dataset.serverFiltersReady = 'true';
        const cards = Array.from(
            browser.querySelectorAll('[data-server-filter-values]')
        );

        const getCardValues = (card) => {
            try {
                const values = JSON.parse(card.dataset.serverFilterValues || '{}');
                return values && typeof values === 'object' ? values : {};
            } catch {
                return {};
            }
        };

        const cardValues = new Map(
            cards.map((card) => [card, getCardValues(card)])
        );

        const syncControlIcon = (select) => {
            const control = select.closest('[data-server-filter-control]');
            const image = control?.querySelector('[data-server-filter-icon]');
            const iconSrc = select.selectedOptions[0]?.dataset.iconSrc || '';

            if (!control || !image) return;

            control.classList.toggle('has-icon', Boolean(iconSrc));
            image.hidden = !iconSrc;

            if (iconSrc) {
                if (image.src !== iconSrc) image.src = iconSrc;
            } else {
                image.removeAttribute('src');
            }
        };

        const applyFilters = () => {
            const activeFilters = selects
                .filter((select) => select.value)
                .map((select) => [select.name, select.value]);

            cards.forEach((card) => {
                const values = cardValues.get(card);
                card.hidden = !activeFilters.every(([key, value]) =>
                    Array.isArray(values[key]) && values[key].includes(value)
                );
            });

            browser.querySelectorAll('.server-tab-panel').forEach((panel) => {
                const panelCards = Array.from(
                    panel.querySelectorAll('[data-server-filter-values]')
                );
                const emptyMessage = panel.querySelector('[data-server-filter-empty]');

                if (emptyMessage) {
                    emptyMessage.hidden = panelCards.some((card) => !card.hidden);
                }
            });
        };

        form.addEventListener('submit', (event) => event.preventDefault());
        form.addEventListener('change', (event) => {
            const select = event.target.closest('[data-server-filter-select]');

            if (!select || !form.contains(select)) return;

            syncControlIcon(select);
            applyFilters();
        });

        selects.forEach(syncControlIcon);
        applyFilters();
    });
};

initServerProductFilters();

document.querySelectorAll('[data-tabs]').forEach((tabs) => {
    if (tabs.dataset.tabsReady === 'true') {
        return;
    }

    const tabList = tabs.querySelector('[role="tablist"]');
    const tabButtons = Array.from(
        tabs.querySelectorAll('[role="tab"]')
    );
    const tabPanels = Array.from(
        tabs.querySelectorAll('[role="tabpanel"]')
    );

    if (!tabList || !tabButtons.length || !tabPanels.length) {
        return;
    }

    tabs.dataset.tabsReady = 'true';
    const mobileQuery = window.matchMedia('(max-width: 1279px)');
    const reducedMotion = window.matchMedia(
        '(prefers-reduced-motion: reduce)'
    );
    const stackOnMobile = tabs.dataset.tabsMobile !== 'tabs';
    const autoplayDelay = Number.parseInt(
        tabs.dataset.tabsAutoplay || '',
        10
    );
    const hasAutoplay =
        Number.isFinite(autoplayDelay) &&
        autoplayDelay >= 1000 &&
        tabButtons.length > 1;
    let autoplayTimer = null;
    let autoplayStartedAt = 0;
    let autoplayRemaining = autoplayDelay;
    let isInViewport = !hasAutoplay;

    const clearAutoplayTimer = () => {
        window.clearTimeout(autoplayTimer);
        autoplayTimer = null;
    };

    const stopAutoplay = () => {
        clearAutoplayTimer();
        autoplayRemaining = autoplayDelay;
        tabs.classList.remove(
            'is-autoplay-running',
            'is-autoplay-paused'
        );
    };

    const activateTab = (activeButton, moveFocus = false) => {
        tabButtons.forEach((button) => {
            const isActive = button === activeButton;
            const panel = tabs.querySelector(
                `#${CSS.escape(button.getAttribute('aria-controls'))}`
            );

            button.setAttribute('aria-selected', String(isActive));
            button.tabIndex = isActive ? 0 : -1;

            if (panel) {
                panel.hidden = !isActive;

                if (isActive) {
                    window.payamLazyImages?.hydrate(panel);
                }
            }
        });

        if (moveFocus) {
            activeButton.focus();
        }
    };

    const scheduleAutoplay = () => {
        stopAutoplay();

        if (
            !hasAutoplay ||
            reducedMotion.matches ||
            mobileQuery.matches ||
            !isInViewport ||
            document.hidden ||
            tabs.matches(':hover') ||
            tabs.contains(document.activeElement)
        ) {
            return;
        }

        tabs.style.setProperty(
            '--services-tabs-autoplay-duration',
            `${autoplayDelay}ms`
        );
        // Force the active tab's progress animation to restart with the timer.
        void tabs.offsetWidth;
        tabs.classList.add('is-autoplay-running');

        autoplayTimer = window.setTimeout(() => {
            const activeIndex = tabButtons.findIndex(
                (button) => button.getAttribute('aria-selected') === 'true'
            );
            const nextIndex = (Math.max(activeIndex, 0) + 1) % tabButtons.length;

            activateTab(tabButtons[nextIndex]);
            scheduleAutoplay();
        }, autoplayDelay);
        autoplayStartedAt = performance.now();
        autoplayRemaining = autoplayDelay;
    };

    const pauseAutoplay = () => {
        if (!autoplayTimer) {
            return;
        }

        autoplayRemaining = Math.max(
            0,
            autoplayRemaining - (performance.now() - autoplayStartedAt)
        );
        clearAutoplayTimer();
        tabs.classList.add('is-autoplay-paused');
    };

    const resumeAutoplay = () => {
        if (
            !hasAutoplay ||
            !tabs.classList.contains('is-autoplay-running') ||
            reducedMotion.matches ||
            mobileQuery.matches ||
            !isInViewport ||
            document.hidden ||
            tabs.matches(':hover') ||
            tabs.contains(document.activeElement)
        ) {
            return;
        }

        tabs.classList.remove('is-autoplay-paused');
        autoplayStartedAt = performance.now();
        autoplayTimer = window.setTimeout(() => {
            const activeIndex = tabButtons.findIndex(
                (button) => button.getAttribute('aria-selected') === 'true'
            );
            const nextIndex = (Math.max(activeIndex, 0) + 1) % tabButtons.length;

            activateTab(tabButtons[nextIndex]);
            scheduleAutoplay();
        }, autoplayRemaining);
    };

    tabList.addEventListener('click', (event) => {
        const button = event.target.closest('[role="tab"]');

        if (!button || !tabList.contains(button)) {
            return;
        }

        activateTab(button);
        scheduleAutoplay();
    });

    tabList.addEventListener('keydown', (event) => {
        const currentIndex = tabButtons.indexOf(document.activeElement);

        if (currentIndex === -1) {
            return;
        }

        let nextIndex = currentIndex;

        switch (event.key) {
            case 'ArrowDown':
            case 'ArrowLeft':
                nextIndex = (currentIndex + 1) % tabButtons.length;
                break;
            case 'ArrowUp':
            case 'ArrowRight':
                nextIndex =
                    (currentIndex - 1 + tabButtons.length) %
                    tabButtons.length;
                break;
            case 'Home':
                nextIndex = 0;
                break;
            case 'End':
                nextIndex = tabButtons.length - 1;
                break;
            default:
                return;
        }

        event.preventDefault();
        activateTab(tabButtons[nextIndex], true);
        scheduleAutoplay();
    });

    const syncTabsMode = (event) => {
        const isMobile = event.matches && stackOnMobile;

        tabList.hidden = isMobile;

        if (isMobile) {
            stopAutoplay();
            tabPanels.forEach((panel, index) => {
                panel.hidden = false;
                panel.setAttribute('role', 'region');
                panel.setAttribute(
                    'aria-label',
                    tabButtons[index]?.textContent.trim() || ''
                );
                panel.removeAttribute('aria-labelledby');
                panel.removeAttribute('tabindex');
            });

            return;
        }

        tabPanels.forEach((panel, index) => {
            panel.setAttribute('role', 'tabpanel');
            panel.setAttribute('aria-labelledby', tabButtons[index].id);
            panel.removeAttribute('aria-label');
            panel.tabIndex = 0;
        });

        const activeButton =
            tabButtons.find(
                (button) =>
                    button.getAttribute('aria-selected') === 'true'
            ) || tabButtons[0];

        activateTab(activeButton);
        scheduleAutoplay();
    };

    syncTabsMode(mobileQuery);
    mobileQuery.addEventListener('change', syncTabsMode);

    if (hasAutoplay) {
        tabs.addEventListener('mouseenter', pauseAutoplay);
        tabs.addEventListener('mouseleave', resumeAutoplay);
        tabs.addEventListener('focusin', pauseAutoplay);
        tabs.addEventListener('focusout', () => {
            window.setTimeout(resumeAutoplay, 0);
        });
        document.addEventListener('visibilitychange', scheduleAutoplay);
        reducedMotion.addEventListener('change', scheduleAutoplay);

        const visibilityObserver = new IntersectionObserver(
            ([entry]) => {
                isInViewport = entry.isIntersecting;

                if (isInViewport) {
                    scheduleAutoplay();
                } else {
                    stopAutoplay();
                }
            },
            { threshold: 0.25 }
        );

        visibilityObserver.observe(tabs);
    }
});

document.querySelectorAll('[data-faq]').forEach((faq) => {
    if (faq.dataset.faqReady === 'true') {
        return;
    }

    const items = Array.from(faq.querySelectorAll('[data-faq-item]'));

    if (!items.length) {
        return;
    }

    faq.dataset.faqReady = 'true';
    const reducedMotion = window.matchMedia(
        '(prefers-reduced-motion: reduce)'
    );

    const getParts = (item) => ({
        button: item.querySelector('[data-faq-toggle]'),
        panel: item.querySelector('[data-faq-panel]'),
        symbol: item.querySelector('[data-faq-symbol]'),
    });

    const setSymbol = (symbol, shouldOpen) => {
        const svg = symbol?.querySelector('svg');
        const use = svg?.querySelector('use');

        if (!svg || !use) {
            return;
        }

        const href = use.getAttribute('href') || '';
        const iconName = shouldOpen ? 'minus' : 'plus';

        use.setAttribute('href', `${href.replace(/#.*$/, '')}#${iconName}`);
        svg.classList.toggle('fill-white', shouldOpen);
        svg.classList.toggle('stroke-blue-primary', !shouldOpen);
    };

    const setState = async (item, shouldOpen) => {
        const { button, panel, symbol } = getParts(item);

        if (!button || !panel) {
            return;
        }

        const transitionId = String(
            Number(panel.dataset.faqTransition || 0) + 1
        );

        panel.dataset.faqTransition = transitionId;
        panel.getAnimations().forEach((animation) => animation.cancel());
        button.setAttribute('aria-expanded', String(shouldOpen));
        item.classList.toggle('is-open', shouldOpen);

        setSymbol(symbol, shouldOpen);

        if (reducedMotion.matches) {
            panel.hidden = !shouldOpen;
            return;
        }

        if (shouldOpen) {
            panel.hidden = false;
        }

        const startHeight = shouldOpen ? 0 : panel.scrollHeight;
        const endHeight = shouldOpen ? panel.scrollHeight : 0;
        const animation = panel.animate(
            [
                { height: `${startHeight}px`, opacity: shouldOpen ? 0 : 1 },
                { height: `${endHeight}px`, opacity: shouldOpen ? 1 : 0 },
            ],
            {
                duration: 280,
                easing: 'ease-out',
            }
        );

        await animation.finished.catch(() => {});

        if (panel.dataset.faqTransition !== transitionId) {
            return;
        }

        if (!shouldOpen) {
            panel.hidden = true;
        }
    };

    faq.addEventListener('click', (event) => {
        const button = event.target.closest('[data-faq-toggle]');

        if (!button || !faq.contains(button)) {
            return;
        }

        const activeItem = button.closest('[data-faq-item]');
        const shouldOpen = button.getAttribute('aria-expanded') !== 'true';

        items.forEach((item) => {
            const itemButton = item.querySelector('[data-faq-toggle]');
            const isOpen = itemButton?.getAttribute('aria-expanded') === 'true';

            if (item === activeItem || isOpen) {
                setState(item, item === activeItem && shouldOpen);
            }
        });
    });
});

const swiperPresets = {
    'os-logos': () => ({
        slidesPerView: 'auto',
        spaceBetween: 16,
        autoplay: false,
        loop: true,
        watchOverflow: true,
        centerInsufficientSlides: true,
        breakpoints: {
            768: {
                slidesPerView: 'auto',
                spaceBetween: 20,
            },
            1280: {
                slidesPerView: 'auto',
                spaceBetween: 24,
            },
        },
    }),
    blog: ({ slideCount }) => ({
        slidesPerView: 1,
        spaceBetween: 21,
        autoplay: false,
        breakpoints: {
            768: {
                slidesPerView: 2,
                spaceBetween: 21,
            },
            1280: {
                slidesPerView: 3,
                spaceBetween: 21,
            },
        },
    }),
    testimonials: ({ slideCount }) => ({
        slidesPerView: 1,
        speed: 650,
        loop: slideCount > 1,
        effect: 'fade',
        fadeEffect: {
            crossFade: true,
        },
        autoplay:
            slideCount > 1
                ? {
                      delay: 5500,
                      disableOnInteraction: false,
                      pauseOnMouseEnter: true,
                  }
                : false,
    }),
};

const parseSwiperOptions = (slider) => {
    if (!slider.dataset.swiperOptions) {
        return {};
    }

    try {
        return JSON.parse(slider.dataset.swiperOptions);
    } catch (error) {
        console.warn('Invalid Swiper options:', slider, error);
        return {};
    }
};

const hydrateSwiperSlide = (slide) => {
    if (slide) {
        window.payamLazyImages?.hydrate(slide);
    }
};

const getVisibleSlideCount = (swiper) => {
    if (swiper.params.slidesPerView === 'auto') {
        return Math.max(1, swiper.slidesPerViewDynamic());
    }

    return Math.max(1, Math.ceil(Number(swiper.params.slidesPerView) || 1));
};

const hydrateSwiperNeighbors = (swiper) => {
    const { slides } = swiper;

    if (!slides.length) {
        return;
    }

    const visibleCount = getVisibleSlideCount(swiper);

    for (let distance = -1; distance <= visibleCount; distance += 1) {
        const index =
            (swiper.activeIndex + distance + slides.length) % slides.length;
        hydrateSwiperSlide(slides[index]);
    }
};

const resolveSwiperControls = (slider, options) => {
    const resolved = { ...options };

    if (slider.querySelector('[data-swiper-pagination]')) {
        resolved.pagination = {
            clickable: true,
            ...(options.pagination || {}),
            el: slider.querySelector('[data-swiper-pagination]'),
        };
    }

    const nextEl = slider.querySelector('[data-swiper-next]');
    const prevEl = slider.querySelector('[data-swiper-prev]');

    if (nextEl || prevEl) {
        resolved.navigation = {
            ...(options.navigation || {}),
            nextEl,
            prevEl,
        };
    }

    return resolved;
};

const initSwipers = () => {
    if (typeof window.Swiper !== 'function') {
        return false;
    }

    document.querySelectorAll('[data-swiper]').forEach((slider) => {
        if (slider.dataset.swiperReady === 'true') {
            return;
        }

        const slides = slider.querySelectorAll('.swiper-wrapper > .swiper-slide');

        if (!slides.length) {
            return;
        }

        slider.dataset.swiperReady = 'true';
        let swiper = null;

        const initSlider = () => {
            if (swiper) {
                return;
            }

            const presetName = slider.dataset.swiper;
            const preset = swiperPresets[presetName]?.({
                slider,
                slideCount: slides.length,
            }) || {};
            const customOptions = parseSwiperOptions(slider);
            const userEvents = {
                ...(preset.on || {}),
                ...(customOptions.on || {}),
            };
            const options = resolveSwiperControls(slider, {
                ...preset,
                ...customOptions,
                loop:
                    slides.length > 1 &&
                    (customOptions.loop ?? preset.loop ?? false),
                autoplay:
                    slides.length > 1
                        ? (customOptions.autoplay ?? preset.autoplay ?? false)
                        : false,
                on: {
                    ...userEvents,
                    init() {
                        hydrateSwiperNeighbors(this);
                        userEvents.init?.call(this);
                    },
                    slideChangeTransitionStart() {
                        hydrateSwiperNeighbors(this);
                        userEvents.slideChangeTransitionStart?.call(this);
                    },
                },
            });

            hydrateSwiperSlide(slides[0]);
            swiper = new window.Swiper(slider, options);

            if (options.autoplay && swiper.autoplay) {
                const visibilityObserver = new IntersectionObserver(
                    ([entry]) => {
                        entry.isIntersecting
                            ? swiper.autoplay.start()
                            : swiper.autoplay.stop();
                    },
                    { threshold: 0.15 }
                );

                visibilityObserver.observe(slider);
            }
        };

        const initObserver = new IntersectionObserver(
            ([entry]) => {
                if (!entry.isIntersecting) {
                    return;
                }

                initSlider();
                initObserver.disconnect();
            },
            {
                rootMargin: '300px 0px',
                threshold: 0,
            }
        );

        initObserver.observe(slider);
    });

    return true;
};

if (!initSwipers()) {
    document.addEventListener('DOMContentLoaded', initSwipers, {
        once: true,
    });
    window.addEventListener('load', initSwipers, { once: true });
}
