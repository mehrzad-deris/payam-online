<?php
/**
 * File Name: asset_registry.php
 */

defined( 'ABSPATH' ) || exit;

/**
 * ACF Flexible Content field name.
 */
const PAYAM_PAGE_BUILDER_FIELD = 'page_builder';

/**
 * Returns an asset version based on the file modification time.
 */
function payam_asset_version( string $relative_path ): string {
	$absolute_path = get_theme_file_path( $relative_path );

	if ( file_exists( $absolute_path ) ) {
		return (string) filemtime( $absolute_path );
	}

	return wp_get_theme()->get( 'Version' );
}

/**
 * Checks whether a theme asset exists.
 */
function payam_asset_exists( string $relative_path ): bool {
	return file_exists( get_theme_file_path( $relative_path ) );
}

/**
 * Converts an ACF layout name to an asset slug.
 */
function payam_get_section_slug( string $layout ): string {
	$slug = preg_replace( '/_section$/', '', $layout );

	return sanitize_key( str_replace( '_', '-', (string) $slug ) );
}

/**
 * Section configuration.
 *
 * Section CSS and JS are detected automatically using this convention:
 *
 * assets/styles/scss/sections/{section-slug}.css
 * assets/js/sections/{section-slug}.js
 *
 * Only additional shared bundles need to be declared here.
 */
function payam_get_section_config(): array {
	return [
		// Legacy layout name: keep existing page-builder rows and load the renamed section assets.
		'hero_section' => [
			'styles'  => [
				'payam-section-domain-check',
			],
			'scripts' => [
				'payam-section-domain-check',
			],
		],

		'domain_check_section' => [],

		'section_heading_section' => [],

		'compare_section' => [],
		'contact_section' => [],

		'hero_section_on_page' => [
			'styles'  => [
				'payam-bundle-cards',
			],
			'scripts' => [
				'payam-bundle-cards',
			],
		],

		'banner_section' => [],

		'seo_box_section' => [],

		'os_logo_section' => [
			'styles'  => [
				'payam-vendor-swiper',
				'payam-bundle-cards',
			],
			'scripts' => [
				'payam-vendor-swiper',
				'payam-bundle-cards',
			],
		],

		'server_card_section' => [
			'styles'  => [
				'payam-bundle-cards',
			],
			'scripts' => [
				'payam-bundle-cards',
			],
		],

		'ssl_products_section' => [
			'styles'  => [
				'payam-bundle-cards',
			],
			'scripts' => [
				'payam-bundle-cards',
			],
		],

		'faq_section' => [
			'styles' => [
				'payam-bundle-cards',
			],
			'scripts' => [
				'payam-bundle-cards',
			],
		],

		'feature_section' => [
			'styles' => [
				'payam-section-feature',
			],
		],

		'feature_section_card_style' => [
			'styles' => [
				'payam-section-feature',
			],
		],

		'statistics_section' => [
			'styles'  => [
				'payam-section-feature',
			],
			'scripts' => [
				'payam-bundle-feature',
			],
		],

		'content_image_section' => [
			'styles' => [
				'payam-section-feature',
			],
		],

		'brands_section' => [
			'styles'  => [
				'payam-section-feature',
			],
			'scripts' => [
				'payam-bundle-feature',
			],
		],

		'testimonials_section' => [
			'styles'  => [
				'payam-vendor-swiper',
				'payam-bundle-cards',
			],
			'scripts' => [
				'payam-vendor-swiper',
				'payam-bundle-cards',
			],
		],

		'services_section' => [
			'styles'  => [
				'payam-bundle-cards',
			],
			'scripts' => [
				'payam-bundle-cards',
			],
		],

		'services_card_section' => [
			'styles' => [
				'payam-bundle-cards',
			],
		],

		'blog_section' => [
			'styles'  => [
				'payam-vendor-swiper',
				'payam-bundle-cards',
			],
			'scripts' => [
				'payam-vendor-swiper',
				'payam-bundle-cards',
			],
		],
	];
}

/**
 * Builds the final section asset registry automatically.
 */
function payam_get_section_assets(): array {
	$registry = [];

	foreach ( payam_get_section_config() as $layout => $config ) {
		$slug = payam_get_section_slug( $layout );

		$style_path = sprintf( '/assets/styles/scss/sections/%s.css', $slug );

		$script_path = sprintf( '/assets/js/sections/%s.min.js', $slug );

		$styles  = $config['styles'] ?? [];
		$scripts = $config['scripts'] ?? [];

		if ( payam_asset_exists( $style_path ) ) {
			$styles[] = 'payam-section-' . $slug;
		}

		if ( payam_asset_exists( $script_path ) ) {
			$scripts[] = 'payam-section-' . $slug;
		}

		$registry[ $layout ] = [
			'styles'  => array_values( array_unique( $styles ) ),
			'scripts' => array_values( array_unique( $scripts ) ),
		];
	}

	return $registry;
}

/**
 * Registers a theme stylesheet when its file exists.
 */
function payam_register_theme_style(
	string $handle, string $relative_path, array $dependencies = []
): bool {
	if ( ! payam_asset_exists( $relative_path ) ) {
		return false;
	}

	return wp_register_style( $handle, get_theme_file_uri( $relative_path ), $dependencies, payam_asset_version( $relative_path ) );
}

/**
 * Registers a theme script when its file exists.
 */
function payam_register_theme_script(
	string $handle, string $relative_path, array $dependencies = []
): bool {
	if ( ! payam_asset_exists( $relative_path ) ) {
		return false;
	}

	return wp_register_script( $handle, get_theme_file_uri( $relative_path ), $dependencies, payam_asset_version( $relative_path ), [
			'strategy'  => 'defer',
			'in_footer' => true,
		] );
}

/**
 * Registers global, vendor, bundle and section assets.
 */
function payam_register_assets(): void {

	/*
	|--------------------------------------------------------------------------
	| Global assets
	|--------------------------------------------------------------------------
	*/

	payam_register_theme_style( 'payam-app', '/assets/styles/theme.min.css' );

	payam_register_theme_script( 'payam-app', '/assets/js/app.min.js' );

	/*
	|--------------------------------------------------------------------------
	| Swiper vendor
	|--------------------------------------------------------------------------
	*/

	payam_register_theme_style( 'payam-vendor-swiper', '/assets/scripts/swiper/swiper-bundle.min.css' );

	payam_register_theme_script( 'payam-vendor-swiper', '/assets/scripts/swiper/swiper-bundle.min.js' );

	/*
	|--------------------------------------------------------------------------
	| Cards bundle
	|--------------------------------------------------------------------------
	*/

	payam_register_theme_style( 'payam-bundle-cards', '/assets/styles/scss/bundles/cards.min.css' );

	payam_register_theme_script( 'payam-bundle-cards', '/assets/js/bundles/cards.min.js', [
			'payam-app',
		] );

	payam_register_theme_script( 'payam-bundle-feature', '/assets/js/bundles/feature.min.js', [
			'payam-app',
		] );

	/*
	|--------------------------------------------------------------------------
	| Section assets
	|--------------------------------------------------------------------------
	*/

	foreach ( array_keys( payam_get_section_config() ) as $layout ) {
		$slug = payam_get_section_slug( $layout );

		$style_path = sprintf( '/assets/styles/scss/sections/%s.css', $slug );

		$script_path = sprintf( '/assets/js/sections/%s.min.js', $slug );

		payam_register_theme_style( 'payam-section-' . $slug, $style_path, [
				'payam-app',
			] );

		payam_register_theme_script( 'payam-section-' . $slug, $script_path, [
				'payam-app',
			] );
	}
}

add_action( 'wp_enqueue_scripts', 'payam_register_assets', 5 );

/**
 * Returns the layouts used in the current page builder.
 */
function payam_get_current_page_layouts(): array {
	if ( ! is_singular() || ! function_exists( 'get_field' ) ) {
		return [];
	}

	$post_id = get_queried_object_id();

	if ( ! $post_id ) {
		return [];
	}

	if ( is_singular( 'post' ) ) {
		$source = payam_article_builder_source( $post_id );
		$sections = get_field( $source['field'], $source['post_id'] );
	} else {
		$sections = get_field( PAYAM_PAGE_BUILDER_FIELD, $post_id );
	}

	if ( ! is_array( $sections ) ) {
		return [];
	}

	$layouts = [];

	foreach ( $sections as $section ) {
		$layout = $section['acf_fc_layout'] ?? '';

		if ( '' !== $layout ) {
			$layouts[] = $layout;
		}
	}

	return array_values( array_unique( $layouts ) );
}

/**
 * Enqueues global and section-specific assets.
 */
function payam_enqueue_assets(): void {
	wp_enqueue_style( 'payam-app' );
	wp_enqueue_script( 'payam-app' );

	$layouts = payam_get_current_page_layouts();

	if ( empty( $layouts ) ) {
		return;
	}

	$registry = payam_get_section_assets();

	$style_handles  = [];
	$script_handles = [];

	foreach ( $layouts as $layout ) {
		if ( ! isset( $registry[ $layout ] ) ) {
			continue;
		}

		$style_handles = array_merge( $style_handles, $registry[ $layout ]['styles'] ?? [] );

		$script_handles = array_merge( $script_handles, $registry[ $layout ]['scripts'] ?? [] );
	}

	$style_handles  = array_values( array_unique( $style_handles ) );
	$script_handles = array_values( array_unique( $script_handles ) );

	// Vendor assets must precede bundles even when another section requested the bundle first.
	if ( in_array( 'payam-vendor-swiper', $style_handles, true ) ) {
		$style_handles = array_values( array_diff( $style_handles, [ 'payam-vendor-swiper' ] ) );
		array_unshift( $style_handles, 'payam-vendor-swiper' );
	}

	if ( in_array( 'payam-vendor-swiper', $script_handles, true ) ) {
		$script_handles = array_values( array_diff( $script_handles, [ 'payam-vendor-swiper' ] ) );
		array_unshift( $script_handles, 'payam-vendor-swiper' );
	}

	foreach ( $style_handles as $handle ) {
		if ( wp_style_is( $handle, 'registered' ) ) {
			wp_enqueue_style( $handle );
		}
	}

	foreach ( $script_handles as $handle ) {
		if ( wp_script_is( $handle, 'registered' ) ) {
			wp_enqueue_script( $handle );
		}
	}
}

add_action( 'wp_enqueue_scripts', 'payam_enqueue_assets', 20 );
